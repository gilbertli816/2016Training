#!/bin/bash
#### compile cpp programs
 
g++ -o bin/main -Iinclude/ src/*.cc
