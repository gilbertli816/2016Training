// reading a text file
#include <iostream>
#include <fstream>
 
using namespace std; 
int main () {
ifstream infile ("example.txt");
ofstream outfile ("output.txt");
int line = 0;
while (infile.good()) {

line++; //update loop number

//temp variable to save input file data
double x = -999;
double y = -999;
infile >> x >> y;

//stop when reach the end of the file
 if(infile.eof()) break;

  cout << "line:" << line << ", " << x << ", " << y <<endl;
  outfile << (x+2) << " " << (y+1) << endl;
 
}//while
 
  infile.close();
  outfile.close();
  
  return 0;
}

