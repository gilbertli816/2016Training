//This is a simple example CGrammar.cxx
/* to explain basic concepts of C Grammars
 * by yangzw, 2008.03.10
 * */
#include <iostream>


int main()
{
  std::cout << "Hello guys!!!" << std::endl;
  int Nevt    = 20   ;//Number of events
  float px    = 10.0 ;//GeV, momentum x
  double mass = 3.1  ;//GeV, mass of particle
  
  for (int i=0; i<10; i++) {
            //  std::cout << "i:" << i << std::endl;
		Nevt++;
		if ( Nevt==21||Nevt>25 ) {
			 std::cout << "Nevt = " << Nevt << std::endl;
		}//end of if
  }//end of for i<10

  return 0;
}
